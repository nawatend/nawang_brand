export default {
  mapBoxToken: '<token>',
};
